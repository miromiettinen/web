function hide(id) {
	document.getElementById(id).style.display = "none";
}
function show(id) {
	document.getElementById(id).style.display = "";
}
